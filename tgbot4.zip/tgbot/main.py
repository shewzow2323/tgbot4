import telebot

bot = telebot.TeleBot("6645661454:AAF3nQYqqHuAhNxfs9-dXz3mLmiGj82BZa4")

currency_dict = {}

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Привет! Я бот для конвертации валют. Воспользуйтесь командами /save_currency и /convert.")

@bot.message_handler(commands=['save_currency'])
def save_currency(message):
    bot.send_message(message.chat.id, "Введите название валюты:")
    bot.register_next_step_handler(message, save_currency_name)

def save_currency_name(message):
    currency_name = message.text
    bot.send_message(message.chat.id, "Введите курс валюты к рублю:")
    bot.register_next_step_handler(message, save_currency_rate, currency_name)

def save_currency_rate(message, currency_name):
    try:
        currency_rate = float(message.text)
        currency_dict[currency_name] = currency_rate
        bot.send_message(message.chat.id, f"Курс валюты {currency_name} успешно сохранен.")
    except ValueError:
        bot.send_message(message.chat.id, "Пожалуйста, введите корректное число для курса валюты.")

@bot.message_handler(commands=['convert'])
def convert_currency(message):
    bot.send_message(message.chat.id, "Введите название валюты для конвертации:")
    bot.register_next_step_handler(message, convert_currency_name)

def convert_currency_name(message):
    currency_name = message.text
    if currency_name in currency_dict:
        currency_rate = currency_dict[currency_name]
        bot.send_message(message.chat.id, f"Введите сумму в валюте {currency_name}:")
        bot.register_next_step_handler(message, convert_currency_amount, currency_rate, currency_name)
    else:
        bot.send_message(message.chat.id, "Указанная валюта не найдена. Пожалуйста, проверьте правильность ввода.")

def convert_currency_amount(message, currency_rate, currency_name):
    try:
        amount = float(message.text)
        converted_amount = amount * currency_rate
        bot.send_message(message.chat.id, f"{amount} {currency_name} равно {converted_amount} рублей.")
    except ValueError:
        bot.send_message(message.chat.id, "Пожалуйста, введите корректную сумму для конвертации.")

bot.polling()
